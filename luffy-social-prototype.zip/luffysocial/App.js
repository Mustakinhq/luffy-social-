import React, { useMemo, useState } from "react";
import {
  Alert,
  Dimensions,
  FlatList,
  Image,
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  Share,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

const { width, height } = Dimensions.get("window");

const C = {
  bg: "#09090b",
  card: "#111114",
  card2: "#18181b",
  text: "#fafafa",
  muted: "#a1a1aa",
  line: "#27272a",
  accent: "#ff2d75",
  purple: "#8b5cf6",
};

const AVATARS = [
  "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=160&q=80",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=160&q=80",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=160&q=80",
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=160&q=80",
  "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=160&q=80",
];

const POSTS = [
  {
    id: "1", user: "maya", name: "Maya Chen", avatar: AVATARS[1],
    image: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1200&q=85",
    caption: "Golden hour never gets old ✨", likes: 1842, comments: 94, liked: false,
  },
  {
    id: "2", user: "arjun", name: "Arjun Mehta", avatar: AVATARS[2],
    image: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=1200&q=85",
    caption: "Somewhere above the clouds.", likes: 927, comments: 41, liked: true,
  },
  {
    id: "3", user: "lina", name: "Lina Park", avatar: AVATARS[3],
    image: "https://images.unsplash.com/photo-1511988617509-a57c8a288659?w=1200&q=85",
    caption: "Weekend energy 🎧", likes: 3310, comments: 172, liked: false,
  },
];

const REELS = [
  { id: "r1", user: "noah", name: "Noah", avatar: AVATARS[4], image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=900&q=90", caption: "Night lights & city vibes", likes: "24.8K", comments: "381" },
  { id: "r2", user: "sara", name: "Sara", avatar: AVATARS[3], image: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=900&q=90", caption: "POV: you found the best concert 🎶", likes: "18.2K", comments: "205" },
  { id: "r3", user: "kai", name: "Kai", avatar: AVATARS[0], image: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=900&q=90", caption: "Turn the volume up.", likes: "9.7K", comments: "119" },
];

const TRENDS = [
  ["#WeekendVibes", "1.2M posts"],
  ["#Travel2026", "842K posts"],
  ["#Music", "728K posts"],
  ["#Foodie", "516K posts"],
  ["#Tech", "394K posts"],
];

function Avatar({ uri, size = 42 }) {
  return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
}

function Icon({ children, active }) {
  return <Text style={[styles.icon, active && { color: C.text }]}>{children}</Text>;
}

function Stories() {
  const stories = [
    ["Your story", AVATARS[0], true], ["Maya", AVATARS[1]], ["Arjun", AVATARS[2]],
    ["Lina", AVATARS[3]], ["Noah", AVATARS[4]],
  ];
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.stories} contentContainerStyle={{ gap: 15 }}>
      {stories.map(([name, uri, own]) => (
        <Pressable key={name} onPress={() => Alert.alert(name, own ? "Create a story from your camera or gallery." : "Story preview")}>
          <View style={[styles.storyRing, own && styles.storyOwn]}>
            <Avatar uri={uri} size={58} />
          </View>
          <Text style={styles.storyName}>{name}</Text>
        </Pressable>
      ))}
    </ScrollView>
  );
}

function PostCard({ post, onLike }) {
  return (
    <View style={styles.post}>
      <View style={styles.postHeader}>
        <Avatar uri={post.avatar} size={40} />
        <View style={{ flex: 1, marginLeft: 10 }}>
          <Text style={styles.bold}>{post.name}</Text>
          <Text style={styles.muted}>@{post.user} · 2h</Text>
        </View>
        <Pressable onPress={() => Alert.alert("Post options", "Mute · Report · Copy link · Not interested")}>
          <Text style={styles.more}>•••</Text>
        </Pressable>
      </View>
      <Image source={{ uri: post.image }} style={styles.postImage} />
      <View style={styles.actions}>
        <Pressable onPress={() => onLike(post.id)}><Text style={[styles.action, post.liked && { color: C.accent }]}>{post.liked ? "♥" : "♡"}</Text></Pressable>
        <Pressable onPress={() => Alert.alert("Comments", "Comments screen can be connected to your backend.")}><Text style={styles.action}>◯</Text></Pressable>
        <Pressable onPress={() => Share.share({ message: `${post.caption} — Luffy Social` })}><Text style={styles.action}>➤</Text></Pressable>
        <View style={{ flex: 1 }} />
        <Pressable><Text style={styles.action}>▱</Text></Pressable>
      </View>
      <Text style={styles.likes}>{post.likes.toLocaleString()} likes</Text>
      <Text style={styles.caption}><Text style={styles.bold}>{post.user} </Text>{post.caption}</Text>
      <Pressable onPress={() => Alert.alert("Comments", `${post.comments} comments`)}>
        <Text style={styles.muted}>View all {post.comments} comments</Text>
      </Pressable>
    </View>
  );
}

function Home({ posts, setPosts }) {
  const onLike = id => setPosts(posts.map(p => p.id === id ? { ...p, liked: !p.liked, likes: p.likes + (p.liked ? -1 : 1) } : p));
  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <Stories />
      {posts.map(p => <PostCard key={p.id} post={p} onLike={onLike} />)}
    </ScrollView>
  );
}

function Reels() {
  return (
    <FlatList
      data={REELS}
      keyExtractor={x => x.id}
      pagingEnabled
      showsVerticalScrollIndicator={false}
      renderItem={({ item }) => (
        <View style={styles.reel}>
          <Image source={{ uri: item.image }} style={StyleSheet.absoluteFillObject} />
          <View style={styles.reelShade} />
          <View style={styles.reelBottom}>
            <View style={{ flex: 1 }}>
              <View style={styles.row}><Avatar uri={item.avatar} size={38} /><Text style={styles.reelUser}>@{item.user}</Text><Pressable style={styles.followBtn} onPress={() => Alert.alert("Following", `You followed @${item.user}`)}><Text style={styles.followText}>Follow</Text></Pressable></View>
              <Text style={styles.reelCaption}>{item.caption}</Text>
              <Text style={styles.music}>♫ Original audio · {item.user}</Text>
            </View>
            <View style={styles.reelActions}>
              <Text style={styles.bigAction}>♥</Text><Text style={styles.stat}>{item.likes}</Text>
              <Text style={styles.bigAction}>◯</Text><Text style={styles.stat}>{item.comments}</Text>
              <Text style={styles.bigAction}>➤</Text>
              <Text style={styles.bigAction}>♫</Text>
            </View>
          </View>
        </View>
      )}
    />
  );
}

function Discover() {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => TRENDS.filter(x => x[0].toLowerCase().includes(q.toLowerCase())), [q]);
  return (
    <ScrollView>
      <View style={styles.search}><Text style={{ color: C.muted }}>⌕</Text><TextInput value={q} onChangeText={setQ} placeholder="Search people, topics, hashtags" placeholderTextColor={C.muted} style={styles.searchInput} /></View>
      <Text style={styles.sectionTitle}>Trending now</Text>
      {filtered.map(([tag, count], i) => (
        <Pressable key={tag} style={styles.trend} onPress={() => Alert.alert(tag, `Explore ${count}`)}>
          <Text style={styles.rank}>{i + 1}</Text>
          <View style={{ flex: 1 }}><Text style={styles.bold}>{tag}</Text><Text style={styles.muted}>{count}</Text></View>
          <Text style={styles.muted}>›</Text>
        </Pressable>
      ))}
      <Text style={styles.sectionTitle}>Explore</Text>
      <View style={styles.grid}>
        {POSTS.concat(POSTS).map((p, i) => <Image key={i} source={{ uri: p.image }} style={styles.gridImage} />)}
      </View>
    </ScrollView>
  );
}

function Profile() {
  return (
    <ScrollView>
      <View style={styles.profileTop}>
        <Avatar uri={AVATARS[0]} size={88} />
        <View style={{ flex: 1, marginLeft: 20 }}>
          <Text style={styles.profileName}>Luffy</Text>
          <Text style={styles.muted}>@luffy</Text>
          <Text style={styles.bio}>Building things. Exploring places. Sharing moments. 🚀</Text>
        </View>
      </View>
      <View style={styles.stats}>
        <View><Text style={styles.statNum}>128</Text><Text style={styles.muted}>Posts</Text></View>
        <View><Text style={styles.statNum}>14.8K</Text><Text style={styles.muted}>Followers</Text></View>
        <View><Text style={styles.statNum}>412</Text><Text style={styles.muted}>Following</Text></View>
      </View>
      <Pressable style={styles.editBtn} onPress={() => Alert.alert("Edit profile", "Connect this button to your profile editor.")}><Text style={styles.bold}>Edit profile</Text></Pressable>
      <View style={styles.profileTabs}><Text style={styles.tabActive}>▦</Text><Text style={styles.muted}>▤</Text><Text style={styles.muted}>♡</Text></View>
      <View style={styles.grid}>{POSTS.map((p, i) => <Image key={i} source={{ uri: p.image }} style={styles.gridImage} />)}</View>
    </ScrollView>
  );
}

function CreateModal({ visible, close, addPost }) {
  const [caption, setCaption] = useState("");
  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.modalBg}>
        <View style={styles.modal}>
          <View style={styles.modalHead}><Text style={styles.modalTitle}>Create post</Text><Pressable onPress={close}><Text style={styles.close}>×</Text></Pressable></View>
          <Pressable style={styles.upload} onPress={() => Alert.alert("Media picker", "In production, connect expo-image-picker or expo-camera here.")}>
            <Text style={{ fontSize: 45 }}>＋</Text><Text style={styles.bold}>Choose photo or video</Text><Text style={styles.muted}>Camera · Gallery · Short video</Text>
          </Pressable>
          <TextInput value={caption} onChangeText={setCaption} placeholder="Write a caption..." placeholderTextColor={C.muted} style={styles.captionInput} multiline />
          <Pressable style={styles.publish} onPress={() => { addPost(caption); setCaption(""); close(); }}>
            <Text style={styles.publishText}>Publish</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

export default function App() {
  const [tab, setTab] = useState("home");
  const [posts, setPosts] = useState(POSTS);
  const [create, setCreate] = useState(false);

  const addPost = caption => {
    setPosts([{ ...POSTS[0], id: String(Date.now()), caption: caption || "New post ✨", likes: 0, comments: 0, liked: false }, ...posts]);
    setTab("home");
  };

  const screen = tab === "home" ? <Home posts={posts} setPosts={setPosts} /> :
    tab === "discover" ? <Discover /> :
    tab === "reels" ? <Reels /> : <Profile />;

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <View style={styles.header}>
        <Text style={styles.logo}>luffy</Text>
        <View style={styles.headerRight}><Pressable onPress={() => Alert.alert("Messages", "DM inbox prototype")}><Text style={styles.headerIcon}>♡</Text></Pressable><Pressable onPress={() => Alert.alert("Messages", "Your messages appear here.")}><Text style={styles.headerIcon}>✈</Text></Pressable></View>
      </View>
      <View style={{ flex: 1 }}>{screen}</View>
      <View style={styles.nav}>
        <Nav label="⌂" active={tab === "home"} onPress={() => setTab("home")} />
        <Nav label="⌕" active={tab === "discover"} onPress={() => setTab("discover")} />
        <Pressable style={styles.create} onPress={() => setCreate(true)}><Text style={styles.createText}>＋</Text></Pressable>
        <Nav label="▶" active={tab === "reels"} onPress={() => setTab("reels")} />
        <Nav label="●" active={tab === "profile"} onPress={() => setTab("profile")} />
      </View>
      <CreateModal visible={create} close={() => setCreate(false)} addPost={addPost} />
    </SafeAreaView>
  );
}

function Nav({ label, active, onPress }) {
  return <Pressable onPress={onPress} style={styles.navItem}><Text style={[styles.navIcon, active && { color: C.text }]}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: { height: 58, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", borderBottomWidth: 1, borderBottomColor: C.line },
  logo: { color: C.text, fontSize: 28, fontWeight: "900", letterSpacing: -1 },
  headerRight: { marginLeft: "auto", flexDirection: "row", gap: 20 },
  headerIcon: { color: C.text, fontSize: 25 },
  stories: { paddingVertical: 14, paddingHorizontal: 15, borderBottomWidth: 1, borderBottomColor: C.line },
  storyRing: { borderWidth: 2, borderColor: C.accent, padding: 2, borderRadius: 34 },
  storyOwn: { borderColor: C.purple },
  storyName: { color: C.muted, fontSize: 11, textAlign: "center", marginTop: 5, width: 64 },
  post: { borderBottomWidth: 1, borderBottomColor: C.line, paddingBottom: 18 },
  postHeader: { flexDirection: "row", alignItems: "center", padding: 12 },
  bold: { color: C.text, fontWeight: "700" },
  muted: { color: C.muted, fontSize: 12, marginTop: 2 },
  more: { color: C.text, fontWeight: "800", fontSize: 16 },
  postImage: { width, height: width * 1.05, backgroundColor: C.card },
  actions: { flexDirection: "row", alignItems: "center", paddingHorizontal: 13, paddingTop: 10, gap: 17 },
  action: { color: C.text, fontSize: 28 },
  likes: { color: C.text, fontWeight: "800", paddingHorizontal: 14, marginTop: 4 },
  caption: { color: C.text, paddingHorizontal: 14, marginTop: 5, lineHeight: 20 },
  storiesPlaceholder: {},
  nav: { height: 65, borderTopWidth: 1, borderTopColor: C.line, backgroundColor: C.bg, flexDirection: "row", alignItems: "center", justifyContent: "space-around" },
  navItem: { width: 55, alignItems: "center" },
  navIcon: { color: C.muted, fontSize: 25, fontWeight: "700" },
  create: { width: 43, height: 34, borderRadius: 10, borderWidth: 1, borderColor: C.text, alignItems: "center", justifyContent: "center" },
  createText: { color: C.text, fontSize: 26, lineHeight: 28 },
  search: { margin: 15, backgroundColor: C.card2, borderRadius: 12, paddingHorizontal: 13, height: 45, flexDirection: "row", alignItems: "center" },
  searchInput: { flex: 1, color: C.text, marginLeft: 8 },
  sectionTitle: { color: C.text, fontSize: 20, fontWeight: "800", padding: 15 },
  trend: { flexDirection: "row", alignItems: "center", paddingHorizontal: 18, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: C.line },
  rank: { color: C.muted, width: 28, fontSize: 14 },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 2 },
  gridImage: { width: (width - 4) / 3, height: (width - 4) / 3 },
  reel: { width, height: height - 123, backgroundColor: "#000" },
  reelShade: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(0,0,0,0.18)" },
  reelBottom: { position: "absolute", left: 15, right: 12, bottom: 22, flexDirection: "row", alignItems: "flex-end" },
  row: { flexDirection: "row", alignItems: "center" },
  reelUser: { color: C.text, fontWeight: "800", marginLeft: 9 },
  followBtn: { marginLeft: 12, borderWidth: 1, borderColor: "#fff", borderRadius: 7, paddingHorizontal: 10, paddingVertical: 5 },
  followText: { color: "#fff", fontWeight: "700", fontSize: 12 },
  reelCaption: { color: "#fff", fontSize: 15, marginTop: 12, fontWeight: "600" },
  music: { color: "#fff", marginTop: 8, fontSize: 12 },
  reelActions: { width: 48, alignItems: "center", gap: 2 },
  bigAction: { color: "#fff", fontSize: 28, marginTop: 10 },
  stat: { color: "#fff", fontSize: 11, fontWeight: "700" },
  profileTop: { flexDirection: "row", padding: 22, alignItems: "center" },
  profileName: { color: C.text, fontSize: 24, fontWeight: "900" },
  bio: { color: C.text, marginTop: 8, lineHeight: 18 },
  stats: { flexDirection: "row", justifyContent: "space-around", paddingVertical: 18, borderTopWidth: 1, borderBottomWidth: 1, borderColor: C.line },
  statsItem: {},
  statNum: { color: C.text, fontWeight: "900", fontSize: 18, textAlign: "center" },
  editBtn: { margin: 15, height: 38, borderRadius: 9, backgroundColor: C.card2, alignItems: "center", justifyContent: "center" },
  profileTabs: { flexDirection: "row", justifyContent: "space-around", paddingVertical: 14, borderTopWidth: 1, borderColor: C.line },
  tabActive: { color: C.text, fontSize: 20 },
  modalBg: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.65)" },
  modal: { backgroundColor: C.card, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, minHeight: 430 },
  modalHead: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modalTitle: { color: C.text, fontSize: 22, fontWeight: "900" },
  close: { color: C.text, fontSize: 32 },
  upload: { height: 190, marginTop: 20, borderRadius: 16, borderWidth: 1, borderColor: C.line, borderStyle: "dashed", alignItems: "center", justifyContent: "center", gap: 5 },
  captionInput: { marginTop: 15, color: C.text, backgroundColor: C.card2, borderRadius: 12, padding: 13, minHeight: 65, textAlignVertical: "top" },
  publish: { marginTop: 15, height: 48, borderRadius: 12, backgroundColor: C.accent, alignItems: "center", justifyContent: "center" },
  publishText: { color: "#fff", fontWeight: "900", fontSize: 16 },
});

