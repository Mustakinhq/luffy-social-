# Luffy Social — cross-platform prototype

A functional social-media UI prototype inspired by the product patterns of Instagram, TikTok and Weibo, but using original branding and implementation.

## Run it

1. Install Node.js.
2. In this folder run:
   ```bash
   npm install
   npx expo start
   ```
3. Scan the QR code with Expo Go, or press:
   - `a` for Android
   - `i` for iOS
   - `w` for web

## Included

- Home feed
- Stories
- Photo posts
- Like state
- Share action
- Discover/search
- Trending topics
- Explore grid
- Full-screen vertical short-video feed
- Follow action
- Profile screen
- Create-post modal
- Responsive Android/iOS/web layout
- Dark visual theme

## Production next steps

This is a frontend prototype. To make it a real social network, connect:
- Auth: Supabase Auth / Firebase Auth
- Database: PostgreSQL via Supabase
- Media: Supabase Storage / S3
- Realtime chat: Supabase Realtime
- Push notifications: Expo Notifications
- Video processing/transcoding: Mux or Cloudflare Stream
- Moderation: automated + human review pipeline
- Recommendation feed: backend ranking service

The image picker/camera and backend are intentionally left as integration points so the prototype stays easy to run.
